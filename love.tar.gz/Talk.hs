-------------------------------------------------------------------------------------------------
{- ********************************************************************************************

                                    Parameters of Many Flavors
                                       Richard A. Eisenberg
                                        rae@richarde.dev
                                       Twitter: @RaeHaskell
                                      https://richarde.dev/

                                      Principal Researcher
                                           Tweag I/O

      This file available at:
         During Haskell Love:             https://richarde.dev/love.tar.gz
                  Afterwards: linked from https://richarde.dev/pubs.html


*********************************************************************************************** -}

{-# LANGUAGE ScopedTypeVariables, TypeApplications, LambdaCase, GADTs,
             StandaloneKindSignatures, PolyKinds, DataKinds, TypeFamilies,
             PatternSynonyms, StandaloneDeriving, DerivingStrategies,
             LinearTypes #-}
{-# OPTIONS_GHC -Wno-unused-matches #-}

module Talk where

import Data.Char ( toUpper )
import Type.Reflection ( eqTypeRep, typeRep, TypeRep, pattern App, withTypeable )
import Data.Typeable ( (:~~:)(HRefl), typeOf, Typeable )
import GHC.TypeLits ( Symbol )
import Data.Kind ( Type )
import Prelude hiding ( const, id )

















--------------------------------------------------------------------
{-

      A **parameter** is an input to a function: it is anything that
      control's the function's behavior.

-}

const :: a -> b -> a
const x y = x

-- QUESTION: How many parameters does `const` have?


























-- ANSWER: 4: two type parameters, and two value parameters

shout :: Show a => a -> String
shout x = map toUpper (show x) ++ "!"

-- QUESTION: How many parameters does `shout` have?






















-- ANSWER: 3: a type parameter, a class dictionary parameter, and a value parameter
-- (a class dictionary gives the runtime implementation of class methods)


















---------------------------------------------------------------------------------------
{-

   We now have seen three different flavors of parameters:
     * type arguments (like `forall a.`)
     * class dictionaries (like `Show a =>`)
     * regular arguments (like `a ->`)

   We can classify these arguments according to three axes:
     * *dependent* = choice of argument affects types of later arguments
     * *relevant*  = needed at runtime
     * *visible*   = must be passed explicitly

                type |  class  | regular
   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   dependent?    YES |   NO    |   NO
   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   relevant?     NO  |   YES   |   YES
   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   visible?      NO  |   NO    |   YES
-}



















----------------------------------------------------------------------------
{-
    Let's rearrange that information:

    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    visible    dependent             ?????
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    visible    non-dependent         regular argument: Int -> ...
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    invisible  dependent             ?????
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    invisible  non-dependent         class dictionary: (Show a) => ...
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  visible    dependent             ?????
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  visible    non-dependent         ?????
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  invisible  dependent             type argument: forall (a :: Type). ...
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  invisible  non-dependent         ?????
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

-}















----------------------------------------------------------------------------------------
{-

    We'll come back to that table. But let's talk about irrelevance for a bit.

-}

id :: a -> a
-- id True = False
id x    = x






























-----------------------------------------------------------------------------
{-

    Haskell: all type arguments are irrelevant

      id :: a -> a
      id x = x

    Idris: you can decide the relevance of each parameter separately

      id : {a : Type} -> a -> a
      id True = False
      id x = x

    Putting the {a : Type} in explicitly makes the parameter relevant.
    (Idris assumes that any implicitly bound parameter is irrelevant.)
-}































---------------------------------------------------------------------
{-

    Haskell's *Typeable* allows runtime type identification.

    In other words, it makes irrelevant arguments relevant.

-}

weirdId :: forall a. Typeable a => a -> a
weirdId
  | Just HRefl <- typeRep @a `eqTypeRep` typeRep @Bool
  = \case True  -> False
          x     -> x
  | otherwise
  = \x -> x

{-
    The details here are unimportant. See https://richarde.dev/papers/2016/dynamic/dynamic.pdf
    But note:
      * We can now match on True and False (like the Idris example)
      * This is *ugly*.
-}
























--------------------------------------------------------------------------------
-- Aside: Why is relevant dependent quantification useful? We need it for fancy types.

data Nat = Zero | Succ Nat

type Vec :: Nat -> Type -> Type             -- this is -XStandaloneKindSignatures
data Vec n a where
  Nil  :: Vec Zero a
  (:>) :: a -> Vec n a -> Vec (Succ n) a
infixr 5 :>
deriving stock instance Show a => Show (Vec n a)

-- produce a vector with n copies of a value
-- NB: The length must be *relevant*, because the runtime behavior requires it
--     The length must be *dependent*, because the result's type depends on it
vReplicate :: forall (n :: Nat) a. Typeable n => a -> Vec n a
vReplicate x
  | Just HRefl <- typeRep @n `eqTypeRep` typeRep @Zero
  = Nil

  | App succ n <- typeRep @n
  , Just HRefl <- succ `eqTypeRep` typeRep @Succ
  = x :> withTypeable n (vReplicate x)

  -- Ew. This approach cannot check for completeness.
  -- And for good reason: it's not complete! See #14420 and #7259
  | otherwise
  = error "impossible"




-----------------------------------------------------------------------
{-

    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    visible    dependent             ?????
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    visible    non-dependent         regular argument: Int -> ...
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    invisible  dependent             Typeable argument: forall a. Typeable a =>    ***
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    invisible  non-dependent         class dictionary: (Show a) => ...
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  visible    dependent             ?????
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  visible    non-dependent         ?????
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  invisible  dependent             type argument: forall (a :: Type). ...
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  invisible  non-dependent         ?????
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    *** ugly

-}







---------------------------------------------------------------------------------------
{-

    Using TypeRep instead of Typeable makes the type argument more visible.

    Type.Reflection exports

      typeRep :: Typeable a => TypeRep a

-}

weirdId2 :: TypeRep a -> a -> a
weirdId2 rep
  | Just HRefl <- rep `eqTypeRep` typeRep @Bool
  = \case True -> False
          x    -> x
  | otherwise
  = \x -> x

charX     = weirdId2 (typeRep @Char) 'x'
boolFalse = weirdId2 (typeRep @Bool) True























charX'     = weirdId2 typeRep 'x'
boolFalse' = weirdId2 typeRep True

-- So, other than requiring the word `typeRep`, this doesn't really require
-- the type argument to be visible.
























-----------------------------------------------------------------------------------------
{-

     Instead, we need **visible dependent quantification**.

-}

{-
weirdId3 :: forall a -> Typeable a => a -> a
weirdId3 a
  | Just HRefl <- typeRep a `eqTypeRep` typeRep @Bool
  = \case True  -> False
          x     -> x
  | otherwise
  = \x -> x
-}

-- Sadly, visible dependent quantification is not implemented






















-- in terms yet. But it is implemented in types.

type WeirdId3 :: forall a -> a -> a
type family WeirdId3 a x where
  WeirdId3 Bool True = False
  WeirdId3 _    x    = x

-- NB: No Typeable. GHC doesn't distinguish relevant/irrelevant in types.
-- All quantification is, effectively, relevant.


















-------------------------------------------------------------------------------------
{-

    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    visible    dependent             Typeable VDQ: forall a -> Typeable a =>       *** ^^^
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    visible    non-dependent         regular argument: Int -> ...
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    invisible  dependent             Typeable argument: forall a. Typeable a =>    ***
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    invisible  non-dependent         class dictionary: (Show a) => ...
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  visible    dependent             VDQ: forall a ->                              ^^^
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  visible    non-dependent         ?????
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  invisible  dependent             type argument: forall (a :: Type). ...
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  invisible  non-dependent         ?????
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    *** ugly
    ^^^ not implemented

-}






















----------------------------------------------------------------------------------
{-  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    visible    dependent             Typeable VDQ: forall a -> Typeable a =>       *** ^^^
                                       in types: VDQ:          forall a ->
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    visible    non-dependent         regular argument: Int -> ...
                                       in types: regular argument: Nat -> ...
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    invisible  dependent             Typeable argument: forall a. Typeable a =>    ***
                                       in types: kind argument:     forall a.
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    invisible  non-dependent         class dictionary: (Show a) => ...
                                       in types: class dictionary: (Show a) => ...             ^^^
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  visible    dependent             VDQ: forall a ->                              ^^^
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  visible    non-dependent         ?????
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  invisible  dependent             type argument: forall (a :: Type). ...
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  invisible  non-dependent         ?????
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    *** ugly
    ^^^ not implemented
    no irrelevant quantification in types (yet)

-}















-------------------------------------------------------------------------------
{-
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  visible    non-dependent         ?????
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  invisible  non-dependent         ?????
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    What about these?

    Something *irrelevant* and *non-dependent* ...
      ... cannot be used in the result
      ... cannot be used in a type

    And thus cannot be used.

    So we don't care about these spots.
-}





















-----------------------------------------------------------------------------
{-  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    visible    dependent             Typeable VDQ: forall a -> Typeable a =>       *** ^^^
                                       in types: VDQ:          forall a ->
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    visible    non-dependent         regular argument: Int -> ...
                                       in types: regular argument: Nat -> ...
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    invisible  dependent             Typeable argument: forall a. Typeable a =>    ***
                                       in types: kind argument:     forall a.
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    invisible  non-dependent         class dictionary: (Show a) => ...
                                       in types: class dictionary: (Show a) => ...             ^^^
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  visible    dependent             VDQ: forall a ->                              ^^^
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  visible    non-dependent         useless
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  invisible  dependent             type argument: forall (a :: Type). ...
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  invisible  non-dependent         useless
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    *** ugly
    ^^^ not implemented
    no irrelevant quantification in types (yet)

-}











---------------------------------------------------------------------------------------------
{-

    Linear types add *multiplicity*.

    But only to relevant, visible, non-dependent parameters.
    That is, normal arguments.

-}

linearConst :: a #-> b -> a
linearConst x y = x





























-----------------------------------------------------------------------------
{-  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    visible    dependent             Typeable VDQ: forall a -> Typeable a =>       *** ^^^
                                       in types: VDQ:          forall a ->
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    visible    non-dependent         regular argument: Int -> ...
                                                           linear: Int #-> ...
                                         multiplicity polymorphic: Int #m-> ...                ^^^
                                       in types: regular argument: Nat -> ...
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    invisible  dependent             Typeable argument: forall a. Typeable a =>    ***
                                       in types: kind argument:     forall a.
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    invisible  non-dependent         class dictionary: (Show a) => ...
                                       in types: class dictionary: (Show a) => ...             ^^^
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  visible    dependent             VDQ: forall a ->                              ^^^
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  visible    non-dependent         useless
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  invisible  dependent             type argument: forall (a :: Type). ...
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  invisible  non-dependent         useless
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    *** ugly
    ^^^ not implemented
    no irrelevant quantification in types (yet)

-}










-----------------------------------------------------------------------
{-

    But Idris shows us that a multiplicity of 0 is the same as irrelevant.

    (GHC today does not support the 0 multiplicity in user code, but it
     exists internally.)

    See also our POPL submission (linked from my publications page):
      https://richarde.dev/papers/2020/quantitative/quantitative.pdf

    This will greatly *simplify* our approach, once multiplicities are allowed
    everywhere.
-}
























--------------------------------------------------------------------------
{-

    There is also the possibility of *matchability*.

    Matchability is important when thinking about unsaturated functions
    during type inference.

    But we will not consider it here.
-}



























-------------------------------------------------------------------
{-

   QUESTION: Some lines in the table are marked as ugly. How can
   we improve?


   ANSWER: 'foreach' quantification.
     https://github.com/goldfirere/ghc-proposals/blob/pi/proposals/0000-pi.rst
-}

{-
weirdId4 :: foreach (a :: Type). a -> a
weirdId4 True = False
weirdId4 x    = x

vReplicate2 :: foreach (n :: Nat). forall a. a -> Vec n a
vReplicate2 @Zero     _ = Nil
vReplicate2 @(Succ n) x = x :> vReplicate x
-}

-- Maybe the foreach/forall distinction should use a multiplicity number, like
-- Idris? Hmm. Will have to think about that one.
























-------------------------------------------------------------------------
{-  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    visible    dependent             Typeable VDQ: forall a -> Typeable a =>       *** ^^^
                                       in types: VDQ:          forall a ->
                                      in future: foreach VDQ:  foreach a ->                    ^^^
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    visible    non-dependent         regular argument: Int -> ...
                                                 linear:           Int #-> ...
                                         multiplicity polymorphic: Int #m-> ...
                                       in types: regular argument: Nat -> ...
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    invisible  dependent             Typeable argument: forall a. Typeable a =>    ***
                                       in types: kind argument:     forall a.
                                      in future: foreach:           foreach a.                 ^^^
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    relevant    invisible  non-dependent         class dictionary: (Show a) => ...
                                       in types: class dictionary: (Show a) => ...             ^^^
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  visible    dependent             VDQ: forall a ->                              ^^^
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  visible    non-dependent         useless
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  invisible  dependent             type argument: forall (a :: Type). ...
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    irrelevant  invisible  non-dependent         useless
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    *** ugly
    ^^^ not implemented
    no irrelevant quantification in types (yet)
-}








--------------------------------------------------------------------------------------
{-

   CONCLUSIONS

     - Haskell already allows parameters of many flavors.

     - The move to dependent Haskell merely de-correlates the choices.
       In particular, allowing dependent types is (essentially) just allowing
       relevant, dependent quantification.

     - Irrelevant quantification is the same as the 0 multiplicity. We have yet to
       work out a syntax that demonstrates this. (We *do* have semantics, via Quantitative
       Type Theory.) But the idea *simplifies* this zoo,
       making relevance and multiplicity the same axis.

-}






























----------------------------------------------------------------------------
{- ********************************************************************************************

                                    Parameters of Many Flavors
                                       Richard A. Eisenberg
                                        rae@richarde.dev
                                       Twitter: @RaeHaskell
                                      https://richarde.dev/

                                      Principal Researcher
                                           Tweag I/O

      This file available at:
         During Haskell Love:             https://richarde.dev/love.tar.gz
                  Afterwards: linked from https://richarde.dev/pubs.html


*********************************************************************************************** -}
