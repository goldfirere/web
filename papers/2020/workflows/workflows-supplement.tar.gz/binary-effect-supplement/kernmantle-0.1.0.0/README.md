# Kernmantle implementation

This package implements the Kernmantle framework as presented in the article.

# Build instructions

After unpacking this tarball, running `stack build` in the kernmantle-0.1.0.0 directory
to build Kernmantle and all the examples.

Note that to build the `biomodel` example, you will need sundials-4.1.0 to be
installed on your system. Download it from here: https://computing.llnl.gov/projects/sundials/download/sundials-4.1.0.tar.gz
sundials requires `cmake` to build. Unpack the archive and _from outside_ of the unpacked folder run:

```
cmake sundials-4.1.0/
make
sudo make install
```

(If you don't `make install`, then you will need to provide the paths of the
sundials libraries and header files, as `hmatrix-sundials` will need them to
build)

`stack run -- biomodel` runs our main use case, storing cached results in the
`/tmp/_store` folder, and writing results and visualizations in the current working directory.

`stack run -- biomodel --help` shows the help page generated from the pipeline
tasks.

# Files of interest

The biomodeling case study is in kernmantle-0.1.0.0/examples/BiomodelUseCase.hs

The code from the paper is in the paper/ directory. It is extracted from the paper source (using lhs2TeX),
with only minor edits. As such, some helper functions are stubbed out; you can view full
definitions in the kernmantle-0.1.0.0/examples directory, but those may have some superficial
differences from what is described in the paper. You can build it with its dependencies with
`cabal build` or examine it in GHCi with `cabal repl`.

