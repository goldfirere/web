{-#  LANGUAGE RankNTypes, LambdaCase, TypeOperators, GADTs, DataKinds, PolyKinds,
             TypeFamilies, DeriveFunctor, AllowAmbiguousTypes, MultiParamTypeClasses,
             NoMonomorphismRestriction, TemplateHaskell, TypeApplications,
             Arrows, ScopedTypeVariables, ConstraintKinds, FlexibleInstances,
             FlexibleContexts, BangPatterns, OverloadedStrings, EmptyDataDeriving,
             StandaloneDeriving, RebindableSyntax, PartialTypeSignatures,
             DerivingVia  #-}

{-#  OPTIONS_GHC -W -Wno-unused-matches -Wno-missing-signatures
                -Wno-unticked-promoted-constructors
                -Wno-partial-type-signatures  #-}
module BinaryEffects where

import Prelude ( Functor(..), Applicative(..), Monoid(..), Monad(..), (<>), ($), String
               , Int, IO, Maybe(..), (++), show, (+), (*), putStrLn, (<$>), (<*>)
               , const, undefined, (-), Double, Show, FilePath, Integer, (/)
               , fromInteger, negate, flip, error, Ord )

import GHC.Exts ( fromString )

import Data.Vector ( Vector )

import Numeric.LinearAlgebra ( Matrix )

import Data.Hashable ( Hashable, hash )

import Data.Map ( Map, (!), fromList )
import Data.Set ( Set, singleton )

import Data.ByteString.Lazy ( ByteString )
import Data.Text ( Text )

import qualified Data.Map as M ( singleton )

import Data.Kind ( Type )
import GHC.TypeLits ( Symbol )

import Data.Dynamic ( Dynamic, toDyn, fromDyn )
import Data.Typeable ( Typeable )

import Data.Functor.Compose ( Compose(..) )

-- needed to support rebindable syntax for arrows
(>>>) :: Task t => t a b -> t b c -> t a c
(>>>) = flip (.)

-- Some classes that are not defined in the paper proper.
class Profunctor (p :: Type -> Type -> Type) where
  dimap :: (a' -> a) -> (b -> b') -> p a b -> p a' b'

class Serializable a where
  serialize :: a -> ByteString
  deserialize :: ByteString -> a
instance Serializable () where
  serialize = mempty
  deserialize _ = ()

class Task t where
  id     :: t a a                                       --  Identity
  (.)    :: t b c -> t a b -> t a c                     --  Composition
  arr    :: (a -> b) -> t a b                           --  Pure task
  first  :: t a b -> t (a, c) (b, c)                    --  Parallel composition

t1, t2, t3 :: Int -> Int
t1 = (+10)
t2 = (*4)
t3 = (*39)

t4 = proc x -> do  y   <-  t1  -<  x
                   z   <-  t2  -<  5
                   t3  -<  x + y + z

t5 = t3 . arr (\(z, (y, x)) -> x + y + z) . first t2 . arr (\yx -> (5, yx)) . first t1 . arr (\x -> (x,x))

instance Task (->) where
  id             = \x -> x
  f . g          = \x -> f (g x)
  arr f          = f
  first f        = \ (b, d) -> (f b, d)

newtype Kleisli m a b = Kleisli (a -> m b)
runKleisli :: Kleisli m a b -> a -> m b
runKleisli (Kleisli action) = action

instance Monad m => Task (Kleisli m) where
  id                             = Kleisli return
  Kleisli f . Kleisli g          = Kleisli (\x -> g x >>= f)
  arr f                          = Kleisli (return . f)
  first (Kleisli act)            = Kleisli (\ (x, y) -> act x >>= (\x' -> return (x', y)))

data WriterA w task a b = WriterA w (task a b)

instance (Monoid w, Task arr) => Task (WriterA w arr) where
  id                                 = WriterA mempty id
  WriterA w1 f . WriterA w2 g        = WriterA (w1<>w2) (f . g)
  arr f                              = WriterA mempty (arr f)
  first (WriterA w t)                = WriterA w (first t)

newtype Cayley f t a b = Cayley (f (t a b))
type (~>) = Cayley
infixr 1 ~>

instance (Applicative f, Task t) => Task (Cayley f t) where
  id                     = Cayley (pure id)
  Cayley p2 . Cayley p1  = Cayley ((.) <$> p2 <*> p1)
  arr f                  = Cayley (pure (arr f))
  first (Cayley p)       = Cayley (fmap first p)

data Writer w a = Writer w a

instance Functor (Writer w) where
  fmap f (Writer w x) = Writer w (f x)
instance Monoid w => Applicative (Writer w) where
  pure x = Writer mempty x
  Writer w1 f <*> Writer w2 x = Writer (w1 <> w2) (f x)
instance Monoid w => Monad (Writer w) where
  Writer w1 a >>= f = case f a of Writer w2 b -> Writer (w1 <> w2) b

newtype Reader r a = Reader (r -> a)
runReader :: Reader r a -> r -> a
runReader (Reader f) = f

instance Functor (Reader r) where
  fmap f (Reader r) = Reader ( \x -> f (r x))
instance Applicative (Reader r) where
  pure x = Reader (\_ -> x)
  Reader f <*> Reader x = Reader (\r -> f r (x r))

type BinEff = * -> * -> *        --  The kind of our binary effects

--  A |Strand| names a binary effect; |Symbol| is just a compile-time (``type-level'') string
data Strand = Symbol :- BinEff

--  A |Mantle| is just a list of strands
type Mantle = [Strand]

--  Extract the effect from a |Strand|
type family StrandEff (t :: Strand) :: BinEff where StrandEff (_ :- eff) = eff

--  A |Weaver| is an interpreter for the effect in |strand|, interpreted in the core task type |core|
type Weaver (core :: BinEff) (strand :: Strand) = forall x y. StrandEff strand x y -> core x y

--  |Weavers| is a heterogeneous list of |Weaver|s, including handlers for many |Strand|s
data Weavers (core :: BinEff) (mantle :: Mantle) where
  WNil   ::  Weavers core '[]
  WCons  ::  Weaver core strand ->  Weavers core mantle ->  Weavers core (strand : mantle)

--  A |Rope core mantle| is a task that can be executed in a core task type |core|
--  when given interpretations for the effects in |mantle|.
newtype Rope (core :: BinEff) (mantle :: Mantle) a b = Rope (Weavers core mantle -> core a b)

instance Task core => Task (Rope core mantle) where
  id = Rope (\ _ -> id)
  Rope r1 . Rope r2 = Rope (\ ws -> r1 ws . r2 ws)
  arr f = Rope (\ _ -> arr f)
  first (Rope r) = Rope (\ ws -> first (r ws))

data LogEff a b where  --  A binary effect type encoded as a GADT
  LogEff :: LogEff String ()

task1 :: Task t => t X Y
task1 = undefined

task2 :: Task t => t Y Z
task2 = undefined

--  A pipeline using this effect:
pipeline   ::  (Task core, InMantle "logger" LogEff mantle)
           =>  Rope core mantle X Z
pipeline = proc input -> do
  a <- task1 -< input
  strand  @"logger" LogEff -< "Task1 completed, computed: " ++ show a
  b <- task2 -< a
  strand  @"logger" LogEff -< "Task2 completed, computed: " ++ show b
  id -< b

--  We interpret our logging effect by printing each logged line to the console:
interpretLogEff :: LogEff a b -> Kleisli IO a b
interpretLogEff LogEff = Kleisli putStrLn

data X
data Y
data Z
deriving instance Show X
deriving instance Show Y
deriving instance Show Z

--  |InMantle name strandEff mantle| says that effect |strandEff| is named |name| in the |mantle|
class InMantle (name :: Symbol) (strandEff :: BinEff) (mantle :: Mantle) where
  --  Extract an interpretation from |strandEff| to a |core| from a |Weavers|
  findWeaver :: Weavers core mantle -> strandEff x y -> core x y

--  These two instances effectively look up a name in mantle.
--  The overlap is harmless when names are unique
instance {-# OVERLAPPING #-} InMantle name strandEff ((name :- strandEff) : mantle) where
  findWeaver (WCons w _) eff = w eff
instance InMantle name strandEff mantle => InMantle name strandEff (other : mantle) where
  findWeaver (WCons _ ws) eff = findWeaver @name @strandEff @mantle ws eff

--  Embed a named effect into a |Rope|
strand  ::  forall strandName strandEff mantle x y core.
            (InMantle strandName strandEff mantle) => strandEff x y -> Rope core mantle x y
strand eff = Rope (\weavers -> findWeaver @strandName @strandEff weavers eff)

--  By supplying an effect handler, reduce the number of effects in a |Rope|'s mantle
weave  ::  forall name strandEff core mantle a b.
           (   (forall x y. Rope core ((name :- strandEff) : mantle) x y -> core x y)
           ->  (forall x y. strandEff x y -> core x y))
       ->  Rope core ((name :- strandEff) : mantle) a b
       ->  Rope core mantle a b
weave interpFn rope = Rope (\weavers ->
  let    run :: forall x y. Rope core ((name :- strandEff) : mantle) x y -> core x y
         run (Rope runRope) = runRope (WCons (interpFn run) weavers)
  in run rope)

--  Simpler form of |weave| that does not allow dependent effects
weave'  ::  forall name strandEff core mantle a b.
            (forall x y. strandEff x y -> core x y)
        ->  Rope core ((name :- strandEff) : mantle) a b
        ->  Rope core mantle a b
weave' interpFn = weave (\ _ -> interpFn)

--  Take a |Rope| without a |mantle| and extract its |core| effect.
untwine :: Rope core '[] a b -> core a b
untwine (Rope runRope) = runRope WNil

runPipeline :: X -> IO Z
runPipeline x =  let pipelineWithoutEffs = weave' @"logger" interpretLogEff pipeline
                 in case untwine pipelineWithoutEffs of Kleisli k -> k x

interpretLogEffWriter :: LogEff a b -> Kleisli (Writer [String]) a b
interpretLogEffWriter LogEff = Kleisli (\logLine -> Writer [logLine] ())

runPipelineWithWriter :: X -> ([String], Z)
runPipelineWithWriter x =
  let pipelineWithoutEffs = weave' @"logger" interpretLogEffWriter pipeline
  in case untwine pipelineWithoutEffs of
    Kleisli k -> case k x of Writer logs result -> (logs, result)

type ResourceId = String   --  A name to identify a resource
data DataSet where
data ReadResource a b where
  ReadDataSet :: ResourceId -> ReadResource () DataSet
  ReadRawFile :: ResourceId -> ReadResource () ByteString

joinDataSetsOnColumn :: Task t => t (DataSet, DataSet, String) DataSet
joinDataSetsOnColumn = undefined

pipeline2  ::  (Task core, InMantle "resources" ReadResource mantle)
          =>  Rope core mantle () DataSet
pipeline2  =   proc () -> do
  dataSet1  <- readDataSet "dataset1" -< ()
  dataSet2  <- readDataSet "dataset2" -< ()
  joinDataSetsOnColumn -< (dataSet1, dataSet2, "Date")
  where
    readDataSet identifier = strand @"resources" (ReadDataSet identifier)

interpretedPipeline ::
  (  Set ResourceId                           --  Requirements collected at load-time
  ,  Map ResourceId FilePath -> IO DataSet )  --  Run-time function taking the final mappings

interpretedPipeline = case untwine (weave' @"resources" interpretReadResource pipeline2) of
  Cayley (Writer resources (Cayley (Reader run))) ->
    (resources, \ mapping -> case run mapping of Kleisli action -> action ())

interpretReadResource
  ::  ReadResource a b
  ->  (Writer (Set ResourceId) ~> Reader (Map ResourceId FilePath) ~> Kleisli IO) a b
interpretReadResource (ReadDataSet ident)
  =   Cayley $ Writer (singleton ident) $
      Cayley $ Reader $ \ mapping -> Kleisli $ \() -> loadDataSet (mapping ! ident)
interpretReadResource (ReadRawFile ident)  =  undefined  ident

loadDataSet :: FilePath -> IO DataSet
loadDataSet = undefined

newtype Config k v a = Config (Writer (Map k (String, Maybe v)) (Reader (Map k v) a))

deriving via (Compose (Writer (Map k (String, Maybe v))) (Reader (Map k v)))
  instance Functor (Config k v)
deriving via (Compose (Writer (Map k (String, Maybe v))) (Reader (Map k v)))
  instance Ord k => Applicative (Config k v)

type CoreEff1 = Config ResourceId FilePath ~> Kleisli IO

interpretedPipeline2 :: (Config ResourceId FilePath ~> Kleisli IO) () DataSet
interpretedPipeline2 = undefined

data GetOpt a b where
  GetOpt  ::  (Show v               --  Allow printing the default value or write to configuration files
          ,   Typeable v)           --  Allow us to use dynamic typing
          =>  String                --  A name for the option
          ->  String                --  A help string
          ->  Maybe v               --  A possible default value
          ->  GetOpt () v

type CoreEff0 = Config String Dynamic ~> Kleisli IO

interpretReadResourceGeneric
  ::  (Task core, InMantle "options" GetOpt mantle, InMantle "io" (Kleisli IO) mantle)
  =>  ReadResource a b
  ->  Rope core mantle a b
interpretReadResourceGeneric (ReadDataSet ident) = proc () -> do
  actualPath <- strand @"options"
    (GetOpt ident ("The source of dataset "++ident) (Just ident)) -< ()
  strand @"io" (Kleisli loadDataSet) -< actualPath
interpretReadResourceGeneric (ReadRawFile _) = undefined

interpretGetOpt (GetOpt name docstring m_default) =
  Cayley $ Config $
  Writer (M.singleton name (docstring, fmap toDyn m_default)) $
  Reader $ \ mapping ->
    arr $ \() -> fromDyn (mapping ! name) (error "wrong type")
interpretIO = Cayley . pure

pipeline8  ::  (Task core, InMantle "resources" ReadResource mantle)
          =>  Rope core mantle () DataSet
pipeline8 = undefined

interpretGetOpt  ::   Task eff => GetOpt a b -> (Config String Dynamic ~> eff) a b
interpretIO      ::   Applicative eff => Kleisli IO a b -> (eff ~> Kleisli IO) a b

interpretedPipeline8  ::  (Config String Dynamic ~> Kleisli IO) () DataSet
interpretedPipeline8  =   untwine $
  weave' @"io"         interpretIO       $  --  "io" strand directly contains Kleisli IO effects
  weave' @"options"    interpretGetOpt   $
  weave @"resources"   (\interp eff -> interp (interpretReadResourceGeneric eff))
  pipeline8

class ProvidesCaching core where
  withStore :: (Hashable a, Serializable b) => Maybe String -> core a b -> core a b

instance ProvidesCaching (Reader Store ~> Kleisli IO) where
  withStore mbName (Cayley runWithStore) =
    Cayley $ Reader $ \store -> Kleisli $ \input -> do
      let inputHash = hash (input, case mbName of Just n -> n; Nothing -> "")
      result <- getFromStore store inputHash
      case result of
        Just r -> return (deserialize r)
        Nothing -> do
          r' <- runKleisli (runReader runWithStore store) input
          addToStore store inputHash (serialize r')
          return r'

type InputHash = Int
data Store

getFromStore :: Store -> InputHash -> IO (Maybe ByteString)
getFromStore = undefined

addToStore :: Store -> InputHash -> ByteString -> IO ()
addToStore = undefined

caching  ::  (ProvidesCaching core, Hashable a, Serializable b)
         =>  Maybe String -> Rope core mantle a b -> Rope core mantle a b
caching mbName (Rope f) = Rope $ \weavers -> withStore mbName (f weavers)

instance {-# OVERLAPPING #-} (Functor f, ProvidesCaching eff)
  => ProvidesCaching (f ~> eff) where withStore mbName (Cayley f) = Cayley (fmap (withStore mbName) f)

data Biomodel params result where
  ODESimulation ::
    { odeSystem :: params -> ODESystem  --  Given the model params, build an ODESystem
    , odePostProcess :: Vector Double -> Matrix Double -> result
        --  Given the time steps used and the solving results, compute the final result
    , odeVarNames :: [Text]  --  Names of the variables (and of the columns of the matrix)
    , odeInitConds :: [Double] } --  Initial values of the variables
     -> Biomodel params result
type ODESystem = Double -> [Double] -> [Double]
instance Profunctor Biomodel where
  dimap f g s@(ODESimulation { odeSystem = sys, odePostProcess = post })
    = s { odeSystem = sys . f, odePostProcess = \x -> g . post x }

type Namespace = [String]   --  components of a name, like |"Model1.Proteins.ForwardSim"|
class Namespaced eff where
  addToNamespace :: String -> eff a b -> eff a b

vanderpol :: Biomodel Double ()
vanderpol = vanderpol'

chemical :: Biomodel Double ()
chemical = chemical'

 --  no type signature: let type inference do the work
pipeline4 = proc () -> do
  strand @"logger" LogEff -< "Beginning pipeline"
  addToNamespace "vanderpol"
    (proc () -> do  mu <- getOpt "mu" "mu parameter" (Just 2) -< ()
                    caching Nothing (strand @"bio" vanderpol) -< mu) -< ()
  addToNamespace "chemical"
    (proc () -> do  k <- getOpt "k" "Left-to-right reaction rate" (Just 2) -< ()
                    caching Nothing (strand @"bio" chemical) -< k) -< ()
  strand @"logger" LogEff -< "Pipeline finished"
  where getOpt n d v = strand @"options" (GetOpt n d v)

vanderpol' :: Biomodel Double ()
vanderpol' =
  ODESimulation (\mu _ [x,v] -> [v, -x + mu * v * (1-x*x)])
             (\ _ _ -> ())
             ["x","v"]
             [1,0]

chemical' :: Biomodel Double ()
chemical' =
  dimap (\k -> (k, k/2)) (const ()) $ --  We derive the two reaction
                                      --  rates from one parameter and ignore the result
    chemicalToODESimulation $
      ChemicalModel (fromList [("H20",1)])
                    (fromList [("H+",2), ("O-",1)])
                    (fromList [("H20",1), ("H+",0), ("O-",0)])

interpretBiomodel
   ::  ( InMantle "options" GetOpt mantle
       , InMantle "logger" LogEff mantle
       , InMantle "files" AccessResource mantle
       , Task core)
   =>  Biomodel a b
   ->  Rope core mantle a b
interpretBiomodel model = proc params -> do
  --  Load the initial conditions:
  ics     <- getOpt "ics"  ("Initial conditions: "++ show (odeVarNames model))
                           (Just $ odeInitConds model)                         -< ()

  --  Load simulation parameters:
  start   <- getOpt "start"       "T0 of simulation"              (Just 0)     -< ()
  end     <- getOpt "end"         "Tmax of simulation"            (Just 50)    -< ()
  points  <- getOpt "timepoints"  "Num timepoints of simulation"  (Just 1000)  -< ()

  --  Simulate the system:
  strand @"logger" LogEff -< "Start solving"
  let   timeVec      = toVector computeSolutionTimes start end points
        ! resMtx  = runModel (odeSystem model params) ics timeVec
          --  The |bang| is to ensure that logging completion happens after computation
  strand @"logger" LogEff -< "Done solving"
  strand @"files" (WriteResource "res" "csv") -<
    serializeResultMatrix (odeVarNames model) timeVec resMtx
  viz <- generateVisualization -< (timeVec, odeVarNames model, resMtx)
  strand @"files" $ WriteResource "viz" "html" -< serializeVisualization viz
  id -< odePostProcess model timeVec resMtx
  where getOpt n d v = strand @"options" (GetOpt n d v)

data AccessResource a b where
  WriteResource :: String -> String -> AccessResource ByteString ()
data CachingContext

data Visualization

serializeVisualization :: Visualization -> ByteString
serializeVisualization = undefined

generateVisualization :: Rope core mantle (Vector Double, [Text], Matrix Double) Visualization
generateVisualization = undefined @_

serializeResultMatrix :: [Text] -> Vector Double -> Matrix Double -> ByteString
serializeResultMatrix = undefined @_

runModel :: ODESystem -> [Double] -> Vector Double -> Matrix Double
runModel = undefined @_

computeSolutionTimes :: dunno
computeSolutionTimes = undefined @_

toVector :: dunno -> Int -> Int -> Int -> dunno2
toVector = undefined @_

data ChemicalModel = ChemicalModel (Map String Integer) (Map String Integer) (Map String Integer)

chemicalToODESolving :: ChemicalModel -> Biomodel (Double, Double) a
chemicalToODESolving = undefined

chemicalToODESimulation = undefined

type CoreEff =
     Reader Namespace          --  Get the namespace we are in. It can be accessed in
                               --  all the remining effects
  ~> Config String Dynamic     --  Accumulate all the wanted options. The final
                               --  option names are contained on the current namespace, as well
                               --  as the default file paths (which are exposed as options, too)
  ~> Writer CachingContext     --  Accumulate the context needed to know what to take
                               --  into account to perform caching
  ~> Reader Store              --  Get a handler to the content store, to cache computations
  ~> Kleisli IO                --  Perform I/O

newtype FreeM f a =
  FreeM { runFree :: forall m. Monad m => (forall x. f x -> m x) -> m a }

type Rope' effects = FreeT (Sums effects)
newtype FreeT t a b = FreeT (forall task. (Task task) => (forall x y. t x y -> task x y) -> task a b)
data (:+:) t1 t2 x y = INL (t1 x y) | INR (t2 x y)
data VoidA x y    --  no constructors

type family Sums (ts :: [Type -> Type -> Type]) where
  Sums '[]       = VoidA
  Sums (t : ts)  = t :+: Sums ts
