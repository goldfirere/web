{- InsertionSortExp.hs

(c) Richard Eisenberg 2012
eir@cis.upenn.edu

This file contains an implementation of insertion sort over natural numbers,
along with a Haskell proof that the sort algorithm is correct. The code below
uses GADTs as proof terms in building up the proof. All proof terms are explicit.

-}

{-# OPTIONS_GHC -fwarn-incomplete-patterns #-}
{-# LANGUAGE TemplateHaskell, TypeOperators, KindSignatures, DataKinds,
             MultiParamTypeClasses, GADTs, TypeFamilies, FlexibleInstances,
             UndecidableInstances, RankNTypes, ScopedTypeVariables,
             PolyKinds, FlexibleContexts, ConstraintKinds #-}

import Data.Singletons

-- Natural numbers, defined with singleton counterparts
$(singletons [d|
  data Nat = Zero | Succ Nat
  |])

-- convenience functions for testing purposes
toNat :: Int -> Nat
toNat 0         = Zero
toNat n | n > 0 = Succ (toNat (n - 1))
toNat _         = error "Converting negative to Nat"

fromNat :: Nat -> Int
fromNat Zero = 0
fromNat (Succ n) = 1 + (fromNat n)

-- A less-than-or-equal relation among naturals
data (a :: Nat) :<=: (b :: Nat) where
  LeZero :: Zero :<=: b
  LeSucc :: a :<=: b -> (Succ a) :<=: (Succ b)

-- A proof term asserting that a list of naturals is in ascending order
data AscendingProof :: [Nat] -> * where
  AscEmpty :: AscendingProof '[]
  AscOne :: AscendingProof '[n]
  AscCons :: a :<=: b -> AscendingProof (b ': rest) ->
              AscendingProof (a ': b ': rest)

-- A proof term asserting that l2 is the list produced when x is inserted
-- (anywhere) into list l1
data InsertionProof x l1 l2 where -- No kind signature possible due to bug #6049
  InsHere :: InsertionProof x l (x ': l)
  InsLater :: InsertionProof x l1 l2 -> InsertionProof x (y ': l1) (y ': l2)

-- A proof term asserting that l1 and l2 are permutations of each other
data PermutationProof l1 l2 where -- No kind signature due to bug #6049
  PermId :: PermutationProof l l
  PermIns :: InsertionProof x l2 l2' -> PermutationProof l1 l2 ->
               PermutationProof (x ': l1) l2'

-- Here is the definition of insertion sort about which we will be reasoning:
$(singletons [d|
  leq :: Nat -> Nat -> Bool
  leq Zero _ = True
  leq (Succ _) Zero = False
  leq (Succ a) (Succ b) = leq a b

  insert :: Nat -> [Nat] -> [Nat]
  insert n [] = [n]
  insert n (h:t) = if leq n h then (n:h:t) else h:(insert n t)

  insertionSort :: [Nat] -> [Nat]
  insertionSort [] = []
  insertionSort (h:t) = insert h (insertionSort t)
  |])

-- A lemma that states if sLeq a b is STrue, then (a :<=: b)
-- This is necessary to convert from the boolean definition of <= to the
-- corresponding proof term
sLeq_true__le :: (Leq a b ~ True) => SNat a -> SNat b -> (a :<=: b)
sLeq_true__le a b = case (a, b) of
  (SZero, SZero) -> LeZero
  (SZero, SSucc _) -> LeZero
  -- (SSucc _, SZero) -> undefined <== IMPOSSIBLE
  (SSucc a', SSucc b') -> LeSucc (sLeq_true__le a' b')
  _ -> error "type checking failed"

-- A lemma that states if sLeq a b is SFalse, then (b :<=: a)
sLeq_false__nle :: (Leq a b ~ False) => SNat a -> SNat b -> (b :<=: a)
sLeq_false__nle a b = case (a, b) of
  -- (SZero, SZero) -> undefined <== IMPOSSIBLE
  -- (SZero, SSucc _) -> undefined <== IMPOSSIBLE
  (SSucc _, SZero) -> LeZero
  (SSucc a', SSucc b') -> LeSucc (sLeq_false__nle a' b')
  _ -> error "type checking failed"

-- A lemma that states that inserting into an ascending list produces an
-- ascending list
insert_ascending :: AscendingProof lst -> SNat n -> Sing lst ->
                      AscendingProof (Insert n lst)
insert_ascending asc n lst =
  case asc of
    AscEmpty -> AscOne -- If lst is empty, then we're done
    AscOne -> case lst of -- If lst has one element...
      -- SNil -> undefined <== IMPOSSIBLE
      SCons h t -> case sLeq n h of -- then check if n is <= h
        STrue -> AscCons (sLeq_true__le n h) asc -- If so, we're done
        SFalse -> AscCons (sLeq_false__nle n h) AscOne -- If not, we're done
      _ -> error "type checking failed"
    AscCons pfLe pfRest -> case lst of -- Otherwise...
      -- SNil -> undefined <== IMPOSSIBLE
      SCons h t -> case sLeq n h of -- check if n <= h
        STrue -> AscCons (sLeq_true__le n h) asc -- If so, we're done
        SFalse -> case t of -- destruct t: lst is (h : h2 : t2)
          -- SNil -> undefined <== IMPOSSIBLE
          SCons h2 t2 -> case sLeq n h2 of -- is n <= h2?
            STrue -> AscCons (sLeq_false__nle n h) -- If so, we're done
                             (AscCons (sLeq_true__le n h2) pfRest)
            SFalse -> -- otherwise, recur on t to build a proof using AscCons
              AscCons pfLe (insert_ascending pfRest n t)
          _ -> error "type checking failed"
      _ -> error "type checking failed"

-- A lemma that states that inserting n into lst produces a new list with n
-- inserted into lst.
insert_insertion :: SNat n -> Sing l -> InsertionProof n l (Insert n l)
insert_insertion n l =
  case l of
    SNil -> InsHere -- if lst is empty, we're done
    SCons h t -> case sLeq n h of -- otherwise, is n <= h?
      STrue -> InsHere -- if so, we're done
      SFalse -> InsLater (insert_insertion n t) -- otherwise, recur

-- A lemma that states that the result of an insertion sort is in ascending order
insertionSort_ascending :: Sing lst -> AscendingProof (InsertionSort lst)
insertionSort_ascending lst = case lst of
  SNil -> AscEmpty -- if the list is empty, we're done

  -- otherwise, we recur to find that insertionSort on t produces an ascending list,
  -- and then we use the fact that inserting into an ascending list produces an
  -- ascending list
  SCons h t -> insert_ascending (insertionSort_ascending t) h (sInsertionSort t)

-- A lemma that states that the result of an insertion sort is a permutation
-- of its input
insertionSort_permutes :: Sing lst -> PermutationProof lst (InsertionSort lst)
insertionSort_permutes lst = case lst of
  SNil -> PermId -- if the list is empty, we're done

  -- otherwise, we wish to use PermIns. We must know that t is a permutation of
  -- the insertion sort of t and that inserting h into the insertion sort of t
  -- works correctly:
  SCons h t ->
    PermIns (insert_insertion h (sInsertionSort t)) (insertionSort_permutes t)

-- A theorem that states that the insertion sort of a list is both ascending
-- and a permutation of the original
insertionSort_correct :: forall (lst :: [Nat]). Sing lst -> (AscendingProof (InsertionSort lst),
                                       PermutationProof lst (InsertionSort lst))
insertionSort_correct lst = (insertionSort_ascending lst,
                             insertionSort_permutes lst)

