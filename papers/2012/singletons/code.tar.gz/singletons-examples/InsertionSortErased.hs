{- InsertionSortErased.hs

(c) Richard Eisenberg 2012
eir@cis.upenn.edu

This file contains the code from InsertionSortExp.hs with extra type information
erased to make the code valid Haskell98. Note that no extensions are used to
compile this file. The purpose of erasing this extra type information is that
we can now use the AProVE (http://aprove.informatik.rwth-aachen.de/) termination
checker. The code in this file can be pasted verbatim into the AProVE's web
interface, and AProVE will certify that the proofs terminate. Because of Haskell's
type erasure property, we know that erasing type information does not change
the runtime behavior of a function. Thus, knowing that the version below terminates
tells us that the original, fully annotated version also terminates.

For commentary on the code, please see InsertionSortExp.hs.

-}

data SNat = SZero | SSucc SNat
data SList a = SNil | SCons a (SList a)
data SBool = SFalse | STrue

data LE = LeZero | LeSucc LE
data AscendingProof = AscEmpty | AscOne | AscCons LE AscendingProof
data InsertionProof = InsHere | InsLater InsertionProof
data PermutationProof = PermId | PermIns InsertionProof PermutationProof

sIf :: SBool -> a -> a -> a
sIf STrue t _ = t
sIf SFalse _ f = f

sLeq :: SNat -> SNat -> SBool
sLeq SZero _ = STrue
sLeq (SSucc _) SZero = SFalse
sLeq (SSucc a) (SSucc b) = sLeq a b

sInsert :: SNat -> SList SNat -> SList SNat
sInsert n SNil = SCons n SNil
sInsert n (SCons h t) = sIf (sLeq n h) (SCons n (SCons h t)) (SCons h (sInsert n t))

sInsertionSort :: SList SNat -> SList SNat
sInsertionSort SNil = SNil
sInsertionSort (SCons h t) = sInsert h (sInsertionSort t)

leq_bool__prop_true :: SNat -> SNat -> LE
leq_bool__prop_true a b = case (a, b) of
  (SZero, SZero) -> LeZero
  (SZero, SSucc _) -> LeZero
  -- (SSucc _, SZero) -> undefined <== IMPOSSIBLE
  (SSucc a', SSucc b') -> LeSucc (leq_bool__prop_true a' b')
  
leq_bool__prop_false :: SNat -> SNat -> LE
leq_bool__prop_false a b = case (a, b) of
  -- (SZero, SZero) -> undefined <== IMPOSSIBLE
  -- (SZero, SSucc _) -> undefined <== IMPOSSIBLE
  (SSucc _, SZero) -> LeZero
  (SSucc a', SSucc b') -> LeSucc (leq_bool__prop_false a' b')

insert_ascending :: AscendingProof -> SNat -> SList SNat -> AscendingProof
insert_ascending asc n lst =
  case asc of
    AscEmpty -> AscOne
    AscOne -> case lst of
      -- SNil -> undefined <== IMPOSSIBLE
      SCons h t -> case sLeq n h of
        STrue -> AscCons (leq_bool__prop_true n h) asc
        SFalse -> AscCons (leq_bool__prop_false n h) AscOne
    AscCons pfLe pfRest -> case lst of
      -- SNil -> undefined <== IMPOSSIBLE
      SCons h t -> case sLeq n h of
        STrue -> AscCons (leq_bool__prop_true n h) asc
        SFalse -> let hLeN = leq_bool__prop_false n h in
         case t of
            -- SNil -> undefined <== IMPOSSIBLE
            SCons h2 t2 -> case sLeq n h2 of
              STrue -> AscCons hLeN (AscCons (leq_bool__prop_true n h2) pfRest)
              SFalse -> AscCons pfLe (insert_ascending pfRest n t)

insert_insertion :: SNat -> SList SNat -> InsertionProof
insert_insertion n l =
  case l of
    SNil -> InsHere
    SCons h t -> case sLeq n h of
      STrue -> InsHere
      SFalse -> InsLater (insert_insertion n t)

insertionSort_works :: SList SNat -> AscendingProof
insertionSort_works SNil = AscEmpty
insertionSort_works (SCons h t) =
  insert_ascending (insertionSort_works t) h (sInsertionSort t)

insertionSort_permutes :: SList SNat -> PermutationProof
insertionSort_permutes SNil = PermId
insertionSort_permutes (SCons h t) =
  PermIns (insert_insertion h (sInsertionSort t)) (insertionSort_permutes t)

insertionSort_correct :: SList SNat -> (AscendingProof, PermutationProof)
insertionSort_correct l = (insertionSort_works l, insertionSort_permutes l)