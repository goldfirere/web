{-# LANGUAGE FunctionalDependencies #-}
{-# OPTIONS_GHC -Wno-simplifiable-class-constraints -Wno-unused-local-binds #-}

module FunDeps where

class Truth
instance Truth

delayInference :: (Truth => r) -> r
delayInference x = x


class FD a b | a -> b where
  fdMethod :: a -> b -> ()

wump x = ()
  where
    blurp y z = [delayInference (fdMethod x y), delayInference (fdMethod x z)]
